package scs.qmsboot;

import java.util.ArrayList;
import java.util.List;

public class StudentServices {
private List<Student> stuList;

public List<Student> getStuList() {
	if(stuList==null)
	{
		stuList = new ArrayList<Student>();
		
	}
	return stuList;
}

public void setStuList(List<Student> stuList) {
	this.stuList = stuList;
}


}
