package scs.qmsboot;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public class StudentModel {
static StudentServices  stu = new StudentServices();
static
{
	stu.getStuList().add(new Student(1001,"STU1"));
	stu.getStuList().add(new Student(1002,"STU2"));
	stu.getStuList().add(new Student(1003,"STU3"));
}

public StudentServices getAllStudent()
{
    return stu;	
}
public void addStudent(Student s)
{
	stu.getStuList().add(s);
}
}
