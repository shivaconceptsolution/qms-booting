package scs.qmsboot;

import org.springframework.boot.SpringApplication;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        SpringApplication.run(StudentController.class,args);
    }
}
