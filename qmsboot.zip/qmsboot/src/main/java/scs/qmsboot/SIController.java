package scs.qmsboot;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
@EnableAutoConfiguration
@Controller
public class SIController {
	@RequestMapping("/si")
	@ResponseBody
	public String calculateSI()
	{
		float p=120000,r=2.2F,t=2,si;
		si = (p*r*t)/100;
		return "Result is "+si;
		
	}

}
